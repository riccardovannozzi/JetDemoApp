export const customers = new webix.DataCollection({
	url:"data/customers.json"
});
