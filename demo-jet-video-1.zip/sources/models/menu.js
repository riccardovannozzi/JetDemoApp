export const data = [
	{ id:"dashboard", icon:"home", value:"Dashboard" },
	{ id:"customers", icon:"account", value:"Customers" },
	{ id:"products", icon:"cube", value:"Products" },
	{ id:"services", icon:"settings", value:"Services"},
	{ id:"orders", icon:"checkbox-marked", value:"Orders" }
];
