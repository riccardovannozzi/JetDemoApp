export const services = new webix.DataCollection({
	url:"data/services.json"
});
