export const products = new webix.DataCollection({
	url:"data/products.json"
});
